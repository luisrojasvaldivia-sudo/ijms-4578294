# Supporting-information inventory — ijms-4578294

All paths below are included in SUPPLEMENTARY_MATERIALS.zip. Numerical files are preserved byte for byte from the supplied manuscript package. The proof edit did not rerun simulations. Original and corrected phase records describe the already archived scientific recovery, not a new recovery during proof editing.

| Label | Included files and interpretation |
|---|---|
| Software S1 | `src/`, `experiments/`, `scripts/`, `tests/`, `configs/pilot.json`, requirements and environment files; five structural/derivative tests in `tests/test_thermo.py`, four encoder-interface tests in `tests/test_review_round2.py`, six recovery checks in `tests/test_phase_recovery.py` |
| Algorithms S1 | `supplementary/Algorithms_S1.pdf`, Algorithms 1–6 in the main TeX/PDF, corresponding Python implementation in `experiments/` and `src/`, frozen `configs/pilot.json` |
| Data S1 | `data/synthetic/binary_train_test.npz`, `data/synthetic/ternary_train_test.npz` |
| Data S2 | All 4 `data/synthetic/binary_binodal_*.csv` files, including fine-grid reference and prediction |
| Results S1 | Entire `results/` directory: seed-level baseline records, revision metrics, model arrays, uncertainty arrays, thermal/dilute diagnostics, TPD and phase records, recovery records, controlled timings and type-II controls |
| Original/corrected phase records | `results/ternary_phase_classification.json`, `results/ternary_phase_classification_corrected.json`, `results/phase_failure_recovery.json`, `results/ternary_flash_records.json` |
| Protocol S1 | `data/experimental/README.md`, `measurements.schema.csv`, `dataset_manifest.template.json`, `experiments/run_external_validation.py`; protocol only, external molecular validation was not executed |
| Appendix A | `supplementary/Appendix_A.pdf`; complete formal proofs also in main TeX/PDF |
| Appendix B | `supplementary/Appendix_B.pdf`; reproducibility protocol and archive structure also in main TeX/PDF; exact file digests in `MANIFEST.sha256` |
| Corrected figures | Entire `figures/`; `scripts/correct_production_figures.py` and original PDFs in `proof_sources/` document presentation-only corrections |

The PDF excerpts retain whole source pages, including any adjacent text sharing those pages. Their page numbers refer to the main compiled proof.

- `Algorithms_S1.pdf`: main-proof pages 22–24.
- `Appendix_A.pdf`: main-proof pages 26–29.
- `Appendix_B.pdf`: main-proof pages 29–30.
