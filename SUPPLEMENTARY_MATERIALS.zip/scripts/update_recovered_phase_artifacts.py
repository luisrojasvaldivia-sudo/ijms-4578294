#!/usr/bin/env python3
"""Recompute phase-panel summaries and Figure 5 after the recorded recovery."""
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments.run_all import COLORS, plt, save_figure


def main():
    file = ROOT / "results/ternary_phase_classification_corrected.json"
    panel = json.loads(file.read_text())
    recovery_path = ROOT / "results/phase_failure_recovery.json"
    recovery = json.loads(recovery_path.read_text())
    records = panel["records"]
    feeds = np.array([r["feed"] for r in records])
    reference = np.array([r["reference"]["n_phases"] == 2 for r in records], dtype=int)
    predicted = np.array([r["model"]["n_phases"] == 2 for r in records], dtype=int)
    matrix = np.array([[np.sum((reference == i) & (predicted == j)) for j in (0,1)] for i in (0,1)])
    margins = np.array([np.linalg.norm(feeds[reference != reference[i]]-z, axis=1).min() for i, z in enumerate(feeds)])
    strata = np.digitize(margins, np.quantile(margins, [1/3,2/3]))
    rows = [{"stratum": name, "count": int(np.sum(strata == i)),
             "agreement_count": int(np.sum((reference == predicted) & (strata == i))),
             "agreement": float(np.mean(reference[strata == i] == predicted[strata == i]))}
            for i, name in enumerate(("near", "intermediate", "interior"))]
    tie, fraction = [], []
    for index, record in enumerate(records):
        record.setdefault("legacy_boundary_distance", record["boundary_distance"])
        record["boundary_distance"] = float(margins[index])
        a, b = record["reference"], record["model"]
        if a["n_phases"] == b["n_phases"] == 2:
            tie.extend(np.abs(np.r_[np.array(a["phase_a"])-b["phase_a"], np.array(a["phase_b"])-b["phase_b"]]).tolist())
            fraction.append(abs(a["beta"]-b["beta"]))
    summary = recovery["corrected_panel"]
    summary.update({"boundary_strata": rows, "tie_line_mae": float(np.mean(tie)),
                    "beta_mae": float(np.mean(fraction)), "joint_two_phase_count": len(fraction)})
    panel["correction_summary"] = summary
    panel["figure_tpd_panel"] = "Historical three-state saturation checks retained; recovered-state checks are in phase_failure_recovery.json."
    file.write_text(json.dumps(panel, indent=2, allow_nan=False)+"\n")
    recovery_path.write_text(json.dumps(recovery, indent=2, allow_nan=False)+"\n")
    def sci(number):
        mantissa, exponent = f"{number:.2e}".split("e")
        return rf"{mantissa}\times10^{{{int(exponent)}}}"
    macros = ["% Generated from the separately archived corrective numerical rerun.",
              rf"\renewcommand{{\PhaseConfusionTN}}{{\rev{{{matrix[0,0]}}}}}",
              rf"\renewcommand{{\PhaseConfusionTP}}{{\rev{{{matrix[1,1]}}}}}",
              rf"\renewcommand{{\PhaseTieMAE}}{{\rev{{${sci(summary['tie_line_mae'])}$}}}}",
              rf"\renewcommand{{\PhaseBetaMAE}}{{\rev{{${sci(summary['beta_mae'])}$}}}}"]
    (ROOT / "sections/phase_recovery_macros.tex").write_text("\n".join(macros)+"\n")
    fig, axes = plt.subplots(1, 3, figsize=(7.6, 2.8))
    axes[0].imshow(matrix, cmap="Blues", vmin=0)
    for i in range(2):
        for j in range(2):
            axes[0].text(j, i, str(matrix[i,j]), ha="center", va="center", fontsize=11,
                         color="#0000ff" if i == j else "black",
                         bbox={"facecolor": "white", "edgecolor": "none", "pad": 2.0} if i == j else None)
    axes[0].set_xticks([0,1], ["One", "Two"])
    axes[0].set_yticks([0,1], ["One", "Two"])
    axes[0].set_xlabel("Predicted phases")
    axes[0].set_ylabel("Reference phases")
    axes[0].set_title("(a) Confusion matrix")
    for label, marker, color, name in ((0,"o",COLORS["reference"],"One phase"), (1,"^",COLORS["potential"],"Two phases")):
        mask = reference == label
        axes[1].scatter(margins[mask], (reference != predicted).astype(float)[mask] + np.random.default_rng(1+label).normal(scale=.018, size=mask.sum()),
                        marker=marker, color=color, alpha=.68, label=name)
    axes[1].set_xlabel("Distance to opposite-class feed")
    axes[1].set_ylabel("Classification error")
    axes[1].set_yticks([0,1], ["Correct","Error"])
    axes[1].set_title("(b) Boundary-stratified errors")
    axes[1].legend(frameon=False)
    saturation = panel["tpd_saturation"]
    indices = list(dict.fromkeys(r["state_index"] for r in saturation))
    for index, marker in zip(indices, ("o","s","^")):
        subset = [r for r in saturation if r["state_index"] == index and r["ftol"] == 1e-12]
        axes[2].plot([r["starts"] for r in subset], [abs(r["minimum"])+1e-16 for r in subset], marker=marker, label=f"State {index}")
    axes[2].set_yscale("log")
    axes[2].set_xlabel("Random TPD starts")
    axes[2].set_ylabel("Absolute minimum TPD")
    axes[2].set_title("(c) Stability-search saturation")
    axes[2].legend(frameon=False)
    fig.tight_layout()
    save_figure(fig, "fig05_ternary_tielines_corrected")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
