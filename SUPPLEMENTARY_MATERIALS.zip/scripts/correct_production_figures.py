"""Resolve IJMS figure-export queries without refitting or changing archived results.
Run from any directory. Source vector PDFs are kept in proof_sources/.
"""
from pathlib import Path
import json,re,shutil,hashlib
import fitz
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
ROOT=Path(__file__).resolve().parents[1];FIG=ROOT/'figures';SRC=ROOT/'proof_sources';SRC.mkdir(exist_ok=True)
for name in ['fig02_binary_fit','fig09_data_efficiency','fig10_thermal_limits']:
 p=SRC/(name+'.pdf')
 if not p.exists():shutil.copy2(FIG/p.name,p)
# Move only the shared colorbar, including its ticks and label; preserve every map cell.
p=fitz.open(SRC/'fig02_binary_fit.pdf');page=p[0];xref=page.get_contents()[0];old=p.xref_stream(xref)
marker=b'/A1 gs 1 g 0 j 0 w 0 G 1 g\n\n470.17925 21.80675 m'
assert old.count(marker)==1
start=old.index(marker);end=old.rfind(b'Q\n')
new=old[:start]+b'q 1 0 0 1 28 0 cm\n'+old[start:end]+b'Q\n'+old[end:]
assert new[:start]==old[:start]
p.update_stream(xref,new);r=page.mediabox;p.xref_set_key(page.xref,'MediaBox',f'[0 0 {r.width+28:.8f} {r.height:.8f}]');p.save(FIG/'fig02_binary_fit.pdf');p.close()
# Move only the thermal-figure legend below the axes and use dotted dilution-direction lines.
p=fitz.open(SRC/'fig10_thermal_limits.pdf');page=p[0];xref=page.get_contents()[0];old=p.xref_stream(xref)
marker=b'2 J 1.5 w 0.8196078431 0.2862745098 0.3568627451 RG /DeviceRGB cs\n281.867 179.16325 m'
assert old.count(marker)==1
start=old.index(marker);end=old.index(b'/A1 gs 1 g 0 j 0 w 0 G 1 g\n\n228.890636',start)
new=old[:start]+b'q 1 0 0 1 0 -202 cm\n'+old[start:end]+b'Q\n'+old[end:]
assert new.count(b'[ 5.55 2.4 ] 0 d')==6
new=new.replace(b'[ 5.55 2.4 ] 0 d',b'[ 0.1 2.4 ] 0 d 1 J')
p.update_stream(xref,new);r=page.mediabox;p.xref_set_key(page.xref,'MediaBox',f'[0 -58 {r.width+5:.8f} {r.height:.8f}]');p.save(FIG/'fig10_thermal_limits.pdf');p.close()
# Replot the robustness figure exclusively from the stored summary values.
m=json.loads((ROOT/'results/revision_metrics.json').read_text())['data_efficiency_noise_ablation']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'legend.fontsize':6.5,'pdf.fonttype':42})
fig,axes=plt.subplots(1,3,figsize=(8.2,2.9),layout='constrained')
colors={'potential':'#d1495b','redlich_kister':'#e9c46a','nrtl_fixed':'#1f4e79'}
for method,label in [('potential','Hard potential'),('redlich_kister','Redlich-Kister'),('nrtl_fixed','Refitted NRTL')]:
 rows=m['efficiency'];x=[r['train_size'] for r in rows]
 axes[0].plot(x,[r[method]['median'] for r in rows],'-o',ms=4,color=colors[method],label=label)
 axes[0].fill_between(x,[r[method]['q1'] for r in rows],[r[method]['q3'] for r in rows],color=colors[method],alpha=.14)
axes[0].set(xscale='log',yscale='log',xlabel='Training states',ylabel='Test MAE',title='(a) Data efficiency');axes[0].legend(frameon=False)
rows=m['noise_sweep'];print('noise record keys:',list(rows[0]))
x=[r['noise_sigma'] if 'noise_sigma' in r else r['sigma'] for r in rows]
axes[1].plot(x,[r['advantage_ratio']['median'] for r in rows],'-o',ms=4,color='#7b2cbf')
axes[1].fill_between(x,[r['advantage_ratio']['q1'] for r in rows],[r['advantage_ratio']['q3'] for r in rows],color='#7b2cbf',alpha=.16)
axes[1].axhline(1,color='.3',lw=.8);axes[1].set(xlabel=r'Training-noise $\sigma$',ylabel='Direct / hard-potential MAE',title='(b) Noise mechanism')
h=[8,16,24,32];l2=[0,1e-9,3e-8,1e-7]
a=np.array([[next(r['validation_mae'] for r in m['ablation'] if r['hidden_units']==i and r['l2']==j) for j in l2] for i in h])
im=axes[2].imshow(a,aspect='auto',cmap='magma_r');axes[2].set_xticks(range(4),['0',r'$10^{-9}$',r'$3\times10^{-8}$',r'$10^{-7}$'],rotation=25);axes[2].set_yticks(range(4),h);axes[2].set(xlabel=r'$\lambda$',ylabel='Hidden units',title='(c) Validation ablation')
fmt=ScalarFormatter(useMathText=True);fmt.set_powerlimits((0,0));fig.colorbar(im,ax=axes[2],fraction=.06,pad=.03,label='Validation MAE',format=fmt)
fig.savefig(FIG/'fig09_data_efficiency.pdf',bbox_inches='tight');plt.close(fig)
for stem in ['fig02_binary_fit','fig09_data_efficiency','fig10_thermal_limits']:
 with fitz.open(FIG/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(3,3),alpha=False).save(FIG/(stem+'.png'))
(ROOT/'FIGURE_CORRECTIONS.json').write_text(json.dumps({'fig02':'Only shared colorbar translated +28 pt horizontally; map stream prefix unchanged.','fig09':'Replotted from archived summary values; scientific-notation labels corrected.','fig10':'Legend moved below axes; second dilution direction dotted; data paths and map values unchanged.','numerical_experiments_rerun':False},indent=2)+'\n')
