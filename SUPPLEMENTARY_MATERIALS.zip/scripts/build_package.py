#!/usr/bin/env python3
"""Validate, compile, hash, and package the IJMS Overleaf project."""

from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ZIP_PATH = ROOT.parent / f"{ROOT.name}.zip"
EXCLUDED_SUFFIXES = {".aux", ".bbl", ".blg", ".fdb_latexmk", ".fls", ".log", ".out", ".toc"}
EXCLUDED_NAMES = {ZIP_PATH.name, "MANIFEST.sha256", "REVISION_ROUND2.md", "update_response_locations.py"}


def run(command: list[str], *, controlled_threads: bool = False) -> None:
    environment = os.environ.copy()
    if controlled_threads:
        environment.update(
            {
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1",
            }
        )
    subprocess.run(command, cwd=ROOT, check=True, env=environment)


def tracked_files():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        if path.name in EXCLUDED_NAMES or path.suffix in EXCLUDED_SUFFIXES:
            continue
        if "__pycache__" in path.parts:
            continue
        relative = path.relative_to(ROOT)
        if relative.parts[0] in {"history", "responses"}:
            continue
        if path.name.startswith(("response_reviewer_", "cover_letter")):
            continue
        yield path


def write_manifest() -> None:
    lines = []
    for path in tracked_files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
    (ROOT / "MANIFEST.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_zip() -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in tracked_files():
            archive.write(path, arcname=f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}")
        archive.write(ROOT / "MANIFEST.sha256", arcname=f"{ROOT.name}/MANIFEST.sha256")


def verify_clean_archive() -> None:
    with tempfile.TemporaryDirectory(prefix="ijms_archive_verify_") as directory:
        with zipfile.ZipFile(ZIP_PATH) as archive:
            archive.extractall(directory)
        extracted = Path(directory) / ROOT.name
        count = 0
        for line in (extracted / "MANIFEST.sha256").read_text().splitlines():
            expected, relative = line.split("  ", 1)
            actual = hashlib.sha256((extracted / relative).read_bytes()).hexdigest()
            if actual != expected:
                raise RuntimeError(f"Archive checksum mismatch: {relative}")
            count += 1
        print(f"Verified {count} manifest entries in a clean ZIP extraction.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-experiments", action="store_true")
    parser.add_argument("--run-recovery", action="store_true", help="rerun only the trace-feed correction, without retraining")
    args = parser.parse_args()
    run(["python3", "tests/test_thermo.py"])
    if args.run_experiments:
        run(["python3", "experiments/run_all.py"], controlled_threads=True)
        run(["python3", "experiments/run_major_revision.py"], controlled_threads=True)
        run(["python3", "experiments/run_type_ii_control.py"], controlled_threads=True)
        run(["python3", "experiments/run_extrapolative_binodal.py"], controlled_threads=True)
    if args.run_experiments or args.run_recovery:
        run(["python3", "experiments/recover_phase_failure.py"], controlled_threads=True)
    run(["python3", "scripts/update_recovered_phase_artifacts.py"])
    run(["python3", "tests/test_review_round2.py", "--report", "results/review_round2_audit.json"])
    run(["python3", "tests/test_phase_recovery.py"])
    run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", "main.tex"])
    run(["python3", "scripts/audit_editorial_structure.py"])
    write_manifest()
    write_zip()
    verify_clean_archive()
    print(ZIP_PATH)


if __name__ == "__main__":
    main()
