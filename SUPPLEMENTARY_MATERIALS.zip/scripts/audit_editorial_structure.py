"""Verify manuscript section order, first-citation numbering and locators."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    main_source = (ROOT / "main.tex").read_text()
    main_body = main_source.split(r"\begin{document}")[1].split(r"\appendixtitles")[0]
    paths = re.findall(r"\\input\{([^}]+)\}", main_body)
    combined = "\n".join((ROOT / (p+".tex")).read_text() for p in paths)
    section_titles = re.findall(r"\\section\{([^\n]+)\}", combined)
    section_titles = [t.replace(r"\rev{", "").replace("}", "") for t in section_titles]
    assert section_titles == ["Introduction", "Results", "Discussion", "Materials and Methods", "Conclusion"], section_titles
    assert combined.count(r"\begin{algorithm}") == 6
    aux = (ROOT / "main.aux").read_text()
    first = []
    for group in re.findall(r"\\citation\{([^}]+)\}", aux):
        for key in group.split(","):
            if key not in first:
                first.append(key)
    bbl = (ROOT / "main.bbl").read_text()
    bib_keys = re.findall(r"\\bibitem(?:\[[\s\S]*?\])?\{([^}]+)\}", bbl)
    assert first == bib_keys, {"first_citations":first,"bibliography":bib_keys}
    for name in ("main",):
        log = (ROOT / f"{name}.log").read_text()
        assert not re.search(r"Overfull|undefined references|Citation .* undefined|Reference .* undefined", log), name
    labels = {k: (n,p) for k,n,p in re.findall(r"\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}", aux)}
    assert labels["sec:results"][0] == "2"
    assert labels["sec:materials_methods"][0] == "4"
    assert labels["sec:pseudocode"][0] == "4.10"
    assert labels["sec:conclusion"][0] == "5"
    report = {"main_sections":section_titles, "algorithm_count":6,
              "pseudocode_section":labels["sec:pseudocode"],
              "reference_count":len(bib_keys), "first_citation_order_verified":True,
              "citation_keys_in_order":first,
              "coi_status":"Standard no-conflicts wording drafted; requires all-author ratification.",
              "numerical_experiments_rerun":False}
    (ROOT / "EDITORIAL_VALIDATION.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
