"""Reproducible numerical core for the IJMS ThermoSciML manuscript."""

