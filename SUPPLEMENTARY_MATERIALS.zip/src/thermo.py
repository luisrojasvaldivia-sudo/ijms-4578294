"""Thermodynamically constrained surrogate models used in the IJMS pilot.

The module deliberately keeps the numerical core small and auditable.  The
learned object is the dimensionless molar excess Gibbs energy, gE/(RT).  All
activity coefficients are derived from that scalar potential.  Consequently,
the Gibbs--Duhem relation is an identity of the representation rather than a
loss penalty.
"""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Callable

import autograd.numpy as anp
import numpy as np
from autograd import grad as autograd_grad
from scipy.optimize import minimize


Array = np.ndarray


def _as_batch(x: Array, temperature: Array | float) -> tuple[Array, Array]:
    x = np.asarray(x, dtype=float)
    if x.ndim == 1:
        x = x[None, :]
    temperature = np.asarray(temperature, dtype=float)
    if temperature.ndim == 0:
        temperature = np.full(x.shape[0], float(temperature))
    if temperature.shape != (x.shape[0],):
        raise ValueError("temperature must be scalar or have one entry per composition")
    if np.any(x <= 0.0) or np.any(x >= 1.0):
        raise ValueError("compositions must lie in the open simplex")
    if not np.allclose(x.sum(axis=1), 1.0, atol=1.0e-10):
        raise ValueError("each composition must sum to one")
    return x, temperature


def nrtl_g_grad_lngamma(
    x: Array,
    temperature: Array | float,
    tau_constant: Array,
    tau_inverse_temperature: Array,
    alpha: Array,
) -> tuple[Array, Array, Array]:
    """Evaluate NRTL gE/(RT), its composition gradient, and ln(gamma).

    The implemented convention is

        gE/(RT) = sum_i x_i [sum_j x_j tau_ji G_ji] / [sum_k x_k G_ki],
        G_ji = exp(-alpha_ji tau_ji).

    Derivatives are analytic, so the reference does not inherit finite-
    difference noise.
    """

    x, temperature = _as_batch(x, temperature)
    nc = x.shape[1]
    tau_constant = np.asarray(tau_constant, dtype=float)
    tau_inverse_temperature = np.asarray(tau_inverse_temperature, dtype=float)
    alpha = np.asarray(alpha, dtype=float)
    expected = (nc, nc)
    if tau_constant.shape != expected or tau_inverse_temperature.shape != expected:
        raise ValueError("NRTL tau matrices have incompatible dimensions")
    if alpha.shape != expected:
        raise ValueError("NRTL alpha matrix has incompatible dimensions")

    tau = tau_constant[None, :, :] + tau_inverse_temperature[None, :, :] / temperature[:, None, None]
    diagonal = np.arange(nc)
    tau[:, diagonal, diagonal] = 0.0
    interaction = np.exp(-alpha[None, :, :] * tau)
    interaction[:, diagonal, diagonal] = 1.0

    denominator = np.einsum("nk,nki->ni", x, interaction)
    numerator = np.einsum("nj,nji->ni", x, tau * interaction)
    ratio = numerator / denominator
    g_excess = np.sum(x * ratio, axis=1)

    # grad[n,m] = partial g_excess[n] / partial x_m before enforcing sum(x)=1.
    correction = (
        x[:, None, :]
        * interaction
        * (tau * denominator[:, None, :] - numerator[:, None, :])
        / denominator[:, None, :] ** 2
    )
    composition_gradient = ratio + np.sum(correction, axis=2)
    weighted_gradient = np.sum(x * composition_gradient, axis=1, keepdims=True)
    ln_gamma = g_excess[:, None] + composition_gradient - weighted_gradient
    return g_excess, composition_gradient, ln_gamma


def ideal_mixing_energy(x: Array) -> Array:
    x = np.asarray(x, dtype=float)
    return np.sum(x * np.log(np.clip(x, 1.0e-14, 1.0)), axis=-1)


def total_mixing_energy(g_excess: Array, x: Array) -> Array:
    return ideal_mixing_energy(x) + np.asarray(g_excess)


@dataclass(frozen=True)
class PairPotentialSpec:
    """Architecture and scaling metadata for the invariant pair potential."""

    embeddings: Array
    hidden_units: int = 14
    temperature_center: float = 370.0
    temperature_scale: float = 80.0

    @property
    def n_components(self) -> int:
        return int(self.embeddings.shape[0])

    @property
    def embedding_dimension(self) -> int:
        return int(self.embeddings.shape[1])

    @property
    def feature_dimension(self) -> int:
        # e_i+e_j, e_i*e_j, (x_i-x_j)(e_i-e_j), x_i+x_j, x_i*x_j, T
        return 3 * self.embedding_dimension + 3

    @property
    def parameter_count(self) -> int:
        h, f = self.hidden_units, self.feature_dimension
        return h * f + h + h + 1


def canonical_embeddings(n_components: int, dimension: int = 3) -> Array:
    if n_components > dimension:
        raise ValueError("embedding dimension must be at least the component count")
    return np.eye(dimension, dtype=float)[:n_components]


def initialize_pair_potential(spec: PairPotentialSpec, seed: int) -> Array:
    rng = np.random.default_rng(seed)
    h, f = spec.hidden_units, spec.feature_dimension
    w = rng.normal(scale=np.sqrt(2.0 / (f + h)), size=(h, f))
    b = rng.normal(scale=0.03, size=h)
    a = rng.normal(scale=0.05, size=h)
    c = np.array([0.0])
    return np.concatenate([w.ravel(), b, a, c])


def _unpack(parameters: Array, spec: PairPotentialSpec):
    h, f = spec.hidden_units, spec.feature_dimension
    cursor = 0
    w = parameters[cursor : cursor + h * f].reshape(h, f)
    cursor += h * f
    b = parameters[cursor : cursor + h]
    cursor += h
    a = parameters[cursor : cursor + h]
    cursor += h
    c = parameters[cursor]
    return w, b, a, c


def pair_potential_g_grad(
    parameters: Array,
    spec: PairPotentialSpec,
    x: Array,
    temperature: Array,
):
    """Return gE/(RT) and all unconstrained composition partial derivatives.

    The symmetric features make each pair contribution invariant to jointly
    swapping component labels, compositions, and embeddings.  Multiplication
    by x_i x_j enforces the pure-component boundary exactly.
    """

    x = anp.asarray(x)
    temperature = anp.asarray(temperature)
    w, b, a, c = _unpack(parameters, spec)
    n_samples, nc = x.shape
    embeddings = anp.asarray(spec.embeddings)
    t_scaled = (temperature - spec.temperature_center) / spec.temperature_scale
    g_excess = anp.zeros(n_samples)
    composition_gradient = anp.zeros((n_samples, nc))

    for i in range(nc):
        for j in range(i + 1, nc):
            xi, xj = x[:, i], x[:, j]
            q = xi * xj
            delta = xi - xj
            e_sum = embeddings[i] + embeddings[j]
            e_product = embeddings[i] * embeddings[j]
            e_difference = embeddings[i] - embeddings[j]
            features = anp.concatenate(
                [
                    anp.tile(e_sum, (n_samples, 1)),
                    anp.tile(e_product, (n_samples, 1)),
                    delta[:, None] * e_difference[None, :],
                    (xi + xj)[:, None],
                    q[:, None],
                    t_scaled[:, None],
                ],
                axis=1,
            )
            pre_activation = anp.dot(features, w.T) + b
            hidden = anp.tanh(pre_activation)
            psi = anp.dot(hidden, a) + c
            g_excess = g_excess + q * psi

            for m in range(nc):
                d_delta = float(m == i) - float(m == j)
                d_sum = float(m == i) + float(m == j)
                d_q = (xj if m == i else 0.0) + (xi if m == j else 0.0)
                d_features = anp.concatenate(
                    [
                        anp.zeros((n_samples, 2 * spec.embedding_dimension)),
                        anp.tile(d_delta * e_difference, (n_samples, 1)),
                        anp.full((n_samples, 1), d_sum),
                        anp.reshape(d_q + anp.zeros(n_samples), (n_samples, 1)),
                        anp.zeros((n_samples, 1)),
                    ],
                    axis=1,
                )
                d_pre_activation = anp.dot(d_features, w.T)
                d_psi = anp.sum(a * (1.0 - hidden**2) * d_pre_activation, axis=1)
                basis = anp.eye(nc)[m]
                contribution = (d_q * psi + q * d_psi)[:, None] * basis[None, :]
                composition_gradient = composition_gradient + contribution

    return g_excess, composition_gradient


def ln_gamma_from_potential(g_excess, composition_gradient, x):
    weighted_gradient = anp.sum(x * composition_gradient, axis=1, keepdims=True)
    return g_excess[:, None] + composition_gradient - weighted_gradient


def pair_potential_predict(
    parameters: Array,
    spec: PairPotentialSpec,
    x: Array,
    temperature: Array | float,
) -> tuple[Array, Array, Array]:
    x, temperature = _as_batch(x, temperature)
    g_excess, composition_gradient = pair_potential_g_grad(parameters, spec, x, temperature)
    ln_gamma = ln_gamma_from_potential(g_excess, composition_gradient, x)
    return np.asarray(g_excess), np.asarray(composition_gradient), np.asarray(ln_gamma)


def pair_potential_temperature_derivative(
    parameters: Array,
    spec: PairPotentialSpec,
    x: Array,
    temperature: Array | float,
) -> Array:
    """Return the analytic derivative of ``gE/(RT)`` with respect to temperature.

    Temperature enters only through the final pair-feature coordinate
    ``(T - T_c) / T_s``.  The expression therefore follows directly from the
    derivative of ``tanh`` and is independent of numerical differencing.
    """

    x, temperature = _as_batch(x, temperature)
    w, b, a, _ = _unpack(np.asarray(parameters, dtype=float), spec)
    embeddings = np.asarray(spec.embeddings, dtype=float)
    t_scaled = (temperature - spec.temperature_center) / spec.temperature_scale
    derivative = np.zeros(x.shape[0], dtype=float)
    for i in range(x.shape[1]):
        for j in range(i + 1, x.shape[1]):
            xi, xj = x[:, i], x[:, j]
            q = xi * xj
            e_sum = embeddings[i] + embeddings[j]
            e_product = embeddings[i] * embeddings[j]
            e_difference = embeddings[i] - embeddings[j]
            features = np.concatenate(
                [
                    np.tile(e_sum, (x.shape[0], 1)),
                    np.tile(e_product, (x.shape[0], 1)),
                    (xi - xj)[:, None] * e_difference[None, :],
                    (xi + xj)[:, None],
                    q[:, None],
                    t_scaled[:, None],
                ],
                axis=1,
            )
            hidden = np.tanh(features @ w.T + b)
            dpsi_dtemperature = np.sum(
                a[None, :] * (1.0 - hidden**2) * w[None, :, -1], axis=1
            ) / spec.temperature_scale
            derivative += q * dpsi_dtemperature
    return derivative


@dataclass
class FitResult:
    parameters: Array
    objective: float
    iterations: int
    converged: bool
    message: str
    elapsed_seconds: float


def fit_pair_potential(
    spec: PairPotentialSpec,
    x_train: Array,
    temperature_train: Array,
    ln_gamma_train: Array,
    *,
    seed: int,
    maxiter: int = 500,
    l2_weight: float = 1.0e-7,
) -> FitResult:
    x_train, temperature_train = _as_batch(x_train, temperature_train)
    target = np.asarray(ln_gamma_train, dtype=float)
    initial = initialize_pair_potential(spec, seed)

    def objective(parameters):
        g_excess, composition_gradient = pair_potential_g_grad(
            parameters, spec, anp.asarray(x_train), anp.asarray(temperature_train)
        )
        prediction = ln_gamma_from_potential(g_excess, composition_gradient, anp.asarray(x_train))
        residual = prediction - target
        return anp.mean(residual**2) + l2_weight * anp.mean(parameters**2)

    objective_gradient: Callable[[Array], Array] = autograd_grad(objective)
    started = perf_counter()
    result = minimize(
        fun=lambda p: float(objective(p)),
        x0=initial,
        jac=lambda p: np.asarray(objective_gradient(p), dtype=float),
        method="L-BFGS-B",
        # The statistical target contains Gaussian perturbations, so driving
        # the optimizer below machine-level tolerances only wastes iterations.
        options={"maxiter": int(maxiter), "ftol": 1.0e-9, "gtol": 1.0e-6, "maxls": 40},
    )
    elapsed = perf_counter() - started
    return FitResult(
        parameters=np.asarray(result.x),
        objective=float(result.fun),
        iterations=int(result.nit),
        converged=bool(result.success),
        message=str(result.message),
        elapsed_seconds=float(elapsed),
    )


def lower_convex_hull_binodal(x_grid: Array, free_energy: Array) -> tuple[float, float] | None:
    """Return the largest interval skipped by the one-dimensional lower hull."""

    x_grid = np.asarray(x_grid, dtype=float)
    free_energy = np.asarray(free_energy, dtype=float)
    hull: list[int] = []
    for idx in range(x_grid.size):
        while len(hull) >= 2:
            i, j = hull[-2], hull[-1]
            slope_ij = (free_energy[j] - free_energy[i]) / (x_grid[j] - x_grid[i])
            slope_jk = (free_energy[idx] - free_energy[j]) / (x_grid[idx] - x_grid[j])
            if slope_ij >= slope_jk:
                hull.pop()
            else:
                break
        hull.append(idx)
    gaps = [(hull[k + 1] - hull[k], hull[k], hull[k + 1]) for k in range(len(hull) - 1)]
    if not gaps:
        return None
    gap, left, right = max(gaps)
    if gap <= 1:
        return None
    return float(x_grid[left]), float(x_grid[right])


def simplex_from_two_coordinates(y: Array) -> Array:
    y = np.asarray(y, dtype=float)
    return np.array([y[0], y[1], 1.0 - y[0] - y[1]], dtype=float)


def flash_two_phase(
    feed: Array,
    g_mixing: Callable[[Array], float],
    *,
    seed: int,
    starts: int = 18,
    ftol: float = 1.0e-12,
    maxiter: int = 600,
) -> dict:
    """Two-phase Gibbs minimization with exact material balances.

    Variables are beta and two independent coordinates of phase A.  Phase B
    follows exactly from the component balances.  Multi-start SLSQP is used;
    the one-phase feed is included as a competing feasible state.
    """

    feed = np.asarray(feed, dtype=float)
    feed = np.clip(feed, 1.0e-9, None)
    feed = feed / feed.sum()
    rng = np.random.default_rng(seed)
    eps = 2.0e-6

    def decode(v):
        beta = float(v[0])
        phase_a = np.array([v[1], v[2], 1.0 - v[1] - v[2]])
        phase_b = (feed - beta * phase_a) / (1.0 - beta)
        return beta, phase_a, phase_b

    def objective(v):
        beta, phase_a, phase_b = decode(v)
        if np.min(phase_a) <= 0.0 or np.min(phase_b) <= 0.0:
            return 1.0e3 + 1.0e3 * (abs(np.minimum(phase_a, 0.0)).sum() + abs(np.minimum(phase_b, 0.0)).sum())
        return beta * g_mixing(phase_a) + (1.0 - beta) * g_mixing(phase_b)

    constraints = [
        {"type": "ineq", "fun": lambda v: 1.0 - eps - v[1] - v[2]},
        {"type": "ineq", "fun": lambda v: np.min(decode(v)[2]) - eps},
    ]
    candidates = []
    total_function_evaluations = 0
    total_iterations = 0
    successful_starts = 0
    deterministic = [
        np.array([0.50, 0.90, 0.08]),
        np.array([0.50, 0.08, 0.08]),
        np.array([0.35, 0.85, 0.12]),
        np.array([0.65, 0.12, 0.12]),
    ]
    starts_list = deterministic[:]
    for _ in range(starts):
        beta = rng.uniform(0.08, 0.92)
        # A convex blend with the feed increases the chance that phase B is feasible.
        raw = rng.dirichlet(np.ones(3))
        lam = rng.uniform(0.05, 0.65)
        phase_a = (1.0 - lam) * feed + lam * raw
        starts_list.append(np.array([beta, phase_a[0], phase_a[1]]))

    for start in starts_list:
        result = minimize(
            objective,
            start,
            method="SLSQP",
            bounds=[(eps, 1.0 - eps), (eps, 1.0 - eps), (eps, 1.0 - eps)],
            constraints=constraints,
            options={"maxiter": int(maxiter), "ftol": float(ftol), "disp": False},
        )
        total_function_evaluations += int(getattr(result, "nfev", 0))
        total_iterations += int(getattr(result, "nit", 0))
        if result.success:
            successful_starts += 1
            beta, phase_a, phase_b = decode(result.x)
            if np.min(phase_a) > 0.0 and np.min(phase_b) > 0.0:
                candidates.append((float(result.fun), beta, phase_a, phase_b, result))

    single_energy = float(g_mixing(feed))
    if not candidates:
        return {
            "n_phases": 1,
            "beta": 1.0,
            "phase_a": feed,
            "phase_b": feed,
            "objective": single_energy,
            "single_energy": single_energy,
            "success": False,
            "candidate_energy": None,
            "candidate_energy_gain": None,
            "candidate_separation": None,
            "best_iterations": 0,
            "total_iterations": total_iterations,
            "total_function_evaluations": total_function_evaluations,
            "successful_starts": successful_starts,
        }
    best = min(candidates, key=lambda item: item[0])
    energy, beta, phase_a, phase_b, result = best
    separation = np.linalg.norm(phase_a - phase_b, ord=1)
    energy_gain = single_energy - energy
    candidate_energy = float(energy)
    candidate_energy_gain = float(energy_gain)
    candidate_separation = float(separation)
    n_phases = 2 if separation > 2.0e-3 and energy_gain > 2.0e-8 else 1
    if n_phases == 1:
        beta, phase_a, phase_b, energy = 1.0, feed, feed, single_energy
    return {
        "n_phases": n_phases,
        "beta": float(beta),
        "phase_a": np.asarray(phase_a),
        "phase_b": np.asarray(phase_b),
        "objective": float(energy),
        "single_energy": single_energy,
        "success": bool(result.success),
        "candidate_energy": candidate_energy,
        "candidate_energy_gain": candidate_energy_gain,
        "candidate_separation": candidate_separation,
        "best_iterations": int(getattr(result, "nit", 0)),
        "total_iterations": total_iterations,
        "total_function_evaluations": total_function_evaluations,
        "successful_starts": successful_starts,
    }


def tangent_plane_distance(
    trial: Array,
    reference_phase: Array,
    ln_gamma_function: Callable[[Array], Array],
) -> float:
    trial = np.asarray(trial, dtype=float)
    reference_phase = np.asarray(reference_phase, dtype=float)
    ln_gamma_trial = np.asarray(ln_gamma_function(trial))
    ln_gamma_reference = np.asarray(ln_gamma_function(reference_phase))
    chemical_trial = np.log(np.clip(trial, 1.0e-14, 1.0)) + ln_gamma_trial
    chemical_reference = np.log(np.clip(reference_phase, 1.0e-14, 1.0)) + ln_gamma_reference
    return float(np.dot(trial, chemical_trial - chemical_reference))


def minimum_tpd(
    reference_phase: Array,
    ln_gamma_function: Callable[[Array], Array],
    *,
    seed: int,
    starts: int = 40,
    ftol: float = 1.0e-12,
) -> float:
    """Return the smallest multistart TPD value.

    Use :func:`minimum_tpd_diagnostics` when convergence saturation and solver
    work counts are required.
    """

    return float(
        minimum_tpd_diagnostics(
            reference_phase,
            ln_gamma_function,
            seed=seed,
            starts=starts,
            ftol=ftol,
        )["minimum"]
    )


def minimum_tpd_diagnostics(
    reference_phase: Array,
    ln_gamma_function: Callable[[Array], Array],
    *,
    seed: int,
    starts: int = 40,
    ftol: float = 1.0e-12,
) -> dict:
    """Return a multistart TPD minimum together with saturation diagnostics."""

    rng = np.random.default_rng(seed)
    eps = 1.0e-8

    def objective(y):
        trial = np.array([y[0], y[1], 1.0 - y[0] - y[1]])
        if np.min(trial) <= 0.0:
            return 1.0e3 + 1.0e3 * abs(np.minimum(trial, 0.0)).sum()
        return tangent_plane_distance(trial, reference_phase, ln_gamma_function)

    candidates = [np.asarray(reference_phase[:2])]
    candidates.extend(rng.dirichlet(np.ones(3), size=starts)[:, :2])
    values = []
    function_evaluations = 0
    iterations = 0
    constraint = {"type": "ineq", "fun": lambda y: 1.0 - eps - y[0] - y[1]}
    for start in candidates:
        result = minimize(
            objective,
            start,
            method="SLSQP",
            bounds=[(eps, 1.0 - eps), (eps, 1.0 - eps)],
            constraints=[constraint],
            options={"maxiter": 300, "ftol": float(ftol)},
        )
        function_evaluations += int(getattr(result, "nfev", 0))
        iterations += int(getattr(result, "nit", 0))
        if result.success:
            values.append(float(result.fun))
    if not values:
        return {
            "minimum": float("nan"),
            "successful_starts": 0,
            "recovery_fraction": 0.0,
            "distinct_minima": 0,
            "function_evaluations": function_evaluations,
            "iterations": iterations,
        }
    minimum = float(min(values))
    tolerance = max(1.0e-9, 10.0 * float(ftol))
    recovery_fraction = float(np.mean(np.asarray(values) <= minimum + tolerance))
    distinct = []
    for value in sorted(values):
        if not distinct or abs(value - distinct[-1]) > tolerance:
            distinct.append(value)
    return {
        "minimum": minimum,
        "successful_starts": len(values),
        "recovery_fraction": recovery_fraction,
        "distinct_minima": len(distinct),
        "function_evaluations": function_evaluations,
        "iterations": iterations,
    }
