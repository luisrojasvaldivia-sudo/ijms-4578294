"""Feasible component-allocation recovery for a failed two-phase flash.

This is a separate corrective solver, not a replacement for archived timings.
It removes the composition floor that excluded trace-component feeds. It does
not certify the continuum global minimum or exclude a third liquid phase.
"""

from __future__ import annotations

from itertools import product

import numpy as np
from scipy.optimize import least_squares, minimize
from scipy.special import softmax


def decode_allocation(feed, allocation):
    z = np.asarray(feed, dtype=float)
    r = np.asarray(allocation, dtype=float)
    if z.ndim != 1 or r.shape != z.shape or np.any(z <= 0):
        raise ValueError("positive feed and matching allocation required")
    if not np.isclose(z.sum(), 1.0, atol=1e-12) or np.any(r <= 0) or np.any(r >= 1):
        raise ValueError("normalized feed and strictly interior allocation required")
    a, b = z * r, z * (1.0 - r)
    beta = float(a.sum())
    return beta, a / beta, b / b.sum()


def allocation_energy_gradient(feed, allocation, energy_mu):
    beta, a, b = decode_allocation(feed, allocation)
    ga, ma = energy_mu(a)
    gb, mb = energy_mu(b)
    return float(beta * ga + (1.0 - beta) * gb), np.asarray(feed) * (ma - mb)


def recover_two_phase(feed, energy_mu, *, random_starts=32, seed=947, ftol=1e-13):
    """Bounded allocation minimization followed by scaled chemical-potential roots.

    The composition of a trace component is never replaced by a fixed floor.
    Exact balances follow from nA_i=z_i*r_i and nB_i=z_i*(1-r_i).
    Root refinement removes the tiny z_i scaling in the energy gradient.
    Only candidates passing independent feasibility and chemical-potential
    tests are accepted. A failed solve stays unresolved (n_phases=None).
    """
    z = np.asarray(feed, float)
    eps = 1e-10
    starts = [np.asarray(r) for r in product((0.05, 0.5, 0.95), repeat=len(z))
              if max(r) - min(r) > 0.1]
    starts += list(np.random.default_rng(seed).uniform(0.02, 0.98, (random_starts, len(z))))
    records, candidates = [], []
    single = float(energy_mu(z)[0])
    for r0 in starts:
        result = minimize(lambda r: allocation_energy_gradient(z, r, energy_mu), r0,
                          jac=True, method="L-BFGS-B", bounds=[(eps, 1-eps)]*len(z),
                          options={"maxiter": 1500, "ftol": ftol, "gtol": 1e-12,
                                   "maxls": 60})
        def residual(r):
            _, a, b = decode_allocation(z, r)
            return energy_mu(a)[1] - energy_mu(b)[1]
        refined = least_squares(residual, np.clip(result.x, 2*eps, 1-2*eps),
                                bounds=(np.full(len(z), eps), np.full(len(z), 1-eps)),
                                xtol=1e-13, ftol=1e-13, gtol=1e-13, max_nfev=1200)
        beta, a, b = decode_allocation(z, refined.x)
        value = allocation_energy_gradient(z, refined.x, energy_mu)[0]
        mu_error = float(np.max(np.abs(residual(refined.x))))
        balance = float(np.max(np.abs(beta*a + (1-beta)*b - z)))
        separation = float(np.linalg.norm(a-b, ord=1))
        gain = single - value
        accepted = bool(refined.success and mu_error <= 1e-8 and balance <= 1e-12
                        and min(a.min(), b.min()) > 0 and value <= single+1e-10
                        and value <= float(result.fun)+1e-9)
        records.append({"minimizer_success": bool(result.success),
                        "refinement_success": bool(refined.success),
                        "accepted": accepted, "objective": value,
                        "chemical_potential_max_residual": mu_error,
                        "material_balance_max_residual": balance,
                        "separation_l1": separation, "energy_gain": gain})
        if accepted and gain > 2e-8 and separation > 2e-3:
            if a[0] < b[0]:
                a, b, beta = b, a, 1-beta
            candidates.append({"n_phases": 2, "success": True, "beta": beta,
                               "phase_a": a.tolist(), "phase_b": b.tolist(),
                               "objective": value, "single_energy": single,
                               "energy_gain": gain, "separation_l1": separation,
                               "chemical_potential_max_residual": mu_error,
                               "material_balance_max_residual": balance})
    if not candidates:
        return {"success": False, "n_phases": None, "start_records": records}
    best = min(candidates, key=lambda r: r["objective"])
    best.update({"start_count": len(starts), "accepted_two_phase_count": len(candidates),
                 "energy_recovery_count": sum(abs(c["objective"]-best["objective"]) < 1e-9 for c in candidates),
                 "start_records": records})
    return best


def tpd_diagnostics(phase, energy_mu, *, random_starts=100, seed=1947):
    """Deterministic plus nested random log-composition local TPD searches.

    Bounds on log ratios [-35,35] are declared; this is not a global bound.
    The reference point itself is also evaluated, but is not counted as a
    converged minimizer unless the optimizer returns a successful status.
    """
    phase = np.asarray(phase)
    m = energy_mu(phase)[1]
    def objective(y):
        w = softmax(np.r_[y, 0.0])
        g, mu = energy_mu(w)
        value = float(g - np.dot(m, w))
        d = mu-m
        return value, w[:-1] * (d[:-1] - np.dot(w, d))
    starts = [np.log(phase[:-1]/phase[-1])]
    starts += [np.array(y, float) for y in product((-25., -15., -5., 0., 5., 15., 25.), repeat=2)]
    rng = np.random.default_rng(seed)
    starts += list(rng.uniform(-30., 30., (random_starts, 2)))
    values, failures, all_values = [], 0, []
    for y in starts:
        fit = minimize(objective, y, method="L-BFGS-B", jac=True,
                       bounds=[(-35., 35.)]*2,
                       options={"ftol": 1e-15, "gtol": 1e-12, "maxiter": 1500, "maxls": 60})
        all_values.append(float(fit.fun))
        if fit.success:
            values.append(float(fit.fun))
        else:
            failures += 1
    return {"minimum_successful": min(values) if values else None,
            "minimum_all_observed": min(all_values), "successful_starts": len(values),
            "failed_starts": failures, "total_starts": len(starts),
            "reference_tpd": float(energy_mu(phase)[0]-np.dot(m, phase)),
            "log_ratio_bounds": [-35., 35.], "global_certificate": False}
